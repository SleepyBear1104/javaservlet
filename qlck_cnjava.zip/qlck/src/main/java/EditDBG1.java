
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditDBG1
 */
@WebServlet("/EditDBG1")
public class EditDBG1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditDBG1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8"); 
		req.setCharacterEncoding("UTF-8"); 
		 PrintWriter out = res.getWriter();  
	    out.println("<html><meta charset='UTF-8'><body>");  
		
		
		// TODO Auto-generated method stub
	    
	    
	    
	    int MACONGTY = Integer.parseInt(req.getParameter("MACONGTY"));
	    Date NGAYDIENBIEN = Date.valueOf(req.getParameter("NGAYDIENBIEN"));
	    int GIA1CHUNGKHOAN = Integer.parseInt(req.getParameter("GIA1CHUNGKHOAN"));
       
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", ""); 
            Statement stmt = con.createStatement();
            String sql = "UPDATE DIENBIENGIA SET GIA1CHUNGKHOAN = ? WHERE MACONGTY = ? AND NGAYDIENBIEN = ? ";
            System.out.println(sql);
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, GIA1CHUNGKHOAN);
            statement.setInt(2, MACONGTY);
            statement.setDate(3, NGAYDIENBIEN);
            
            statement.executeUpdate();
            res.sendRedirect("DSDBG");
            stmt.close();
            statement.close();
            con.close();
             
        } catch (Exception e) {
          System.out.println("Error");
        }
        }

}
