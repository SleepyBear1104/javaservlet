
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DSKH
 */
@WebServlet("/DSKH")
public class DSKH extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DSKH() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setCharacterEncoding("UTF-8");
        PrintWriter out = res.getWriter();  
        res.setContentType("text/html");
        
        out.println("<html> <head> <link rel=\"stylesheet\" href=\"form.css\" /> <link rel=\"stylesheet\" href=\"tables.css\" /></head> <body>");
        out.println("<div class=\"header\">\r\n"
        		+ "        <div class=\"bar\">\r\n"
        		+ "            <div class=\"menu\">\r\n"
        		+ "                <ul>\r\n"
        		+ "                    <li></li>\r\n"
        		+ "                    <li><a href=\"home.html\">Trang Chủ</a></li>\r\n"
        		+ "                    <li><a href=\"DSNMG\">Nhà Môi Giới</a></li>\r\n"
        		+ "                    <li><a href=\"DSKH\">Khách Hàng</a></li>\r\n"
        		+ "                    <li><a href=\"DSCT\">Công Ty</a></li>\r\n"
        		+ "                    <li><a href=\"DSGD\">Giao Dịch</a></li>\r\n"
        		+ "                    <li><a href=\"DSDBG\">Diễn Biến Giá</a></li>\r\n"
        		+ "                </ul>\r\n"
        		+ "            </div>\r\n"
        		+ "        </div>\r\n"
        		+ "    </div>	");
        try 
        {  
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", "");  
            Statement stmt = con.createStatement();  
            String sql="select * from KHACHHANG";
            
            ResultSet rs = stmt.executeQuery(sql); 
            
            out.println("<table class=customers>");
            out.println("<tr><th>Mã Khách Hàng</th>"
            		+ "<th>Tên Khách Hàng</th>"
            		+ "<th>Địa chỉ</th>"
            		+ "<th>Số điện thoại</th>"
            		+ "<th>Tổng thu nhập</th>"
            		+ "<th><a href=\"SearchKH.html\">Tìm Kiếm</a> | <a href='createKH.html'>Thêm Mới</a></th></tr>");
            while (rs.next()) 
            {  
            	int MAKHACHHANG = rs.getInt("MAKHACHHANG");
            	String TENKHACHHANG = rs.getString("TENKHACHHANG");
            	String DIACHI = rs.getString("DIACHI");
            	String SDT= rs.getString("SDT");
            	int TONGTHUNHAP= rs.getInt("TONGTHUNHAP");
            	
            	
            	
            	out.println("<tr><td>" + MAKHACHHANG +
            			"</td><td>" + TENKHACHHANG + 
            			" </td> <td>" + DIACHI + 
            			" </td> <td>" + SDT + 
            			" </td><td>" + TONGTHUNHAP + 
            			" </td><td>" + "<a href='editKH1.jsp?MAKHACHHANG="+MAKHACHHANG+"&TENKHACHHANG="+TENKHACHHANG+"&DIACHI="+DIACHI+"&SDT="+SDT+"&TONGTHUNHAP="+TONGTHUNHAP+"'>Sửa</a> | " + "<a href='deleteKH.html'>Xóa</a>  " + "</td></tr>");
            }  
            out.println("</table>");
            out.println("</html></body>");  
            con.close();  
         }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
    }  
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		
	}

}
