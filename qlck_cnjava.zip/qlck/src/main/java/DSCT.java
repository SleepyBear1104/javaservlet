
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DSCT
 */
@WebServlet("/DSCT")
public class DSCT extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DSCT() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setCharacterEncoding("UTF-8");
        PrintWriter out = res.getWriter();  
        res.setContentType("text/html");  
        out.println("<html> <head> <link rel=\"stylesheet\" href=\"form.css\" /><link rel=\"stylesheet\" href=\"tables.css\" /></head> <body>");
        out.println("<div class=\"header\">\r\n"
        		+ "        <div class=\"bar\">\r\n"
        		+ "            <div class=\"menu\">\r\n"
        		+ "                <ul>\r\n"
        		+ "                    <li></li>\r\n"
        		+ "                    <li><a href=\"home.html\">Trang Chủ</a></li>\r\n"
        		+ "                    <li><a href=\"DSNMG\">Nhà Môi Giới</a></li>\r\n"
        		+ "                    <li><a href=\"DSKH\">Khách Hàng</a></li>\r\n"
        		+ "                    <li><a href=\"DSCT\">Công Ty</a></li>\r\n"
        		+ "                    <li><a href=\"DSGD\">Giao Dịch</a></li>\r\n"
        		+ "                    <li><a href=\"DSDBG\">Diễn Biến Giá</a></li>\r\n"
        		+ "                </ul>\r\n"
        		+ "            </div>\r\n"
        		+ "        </div>\r\n"
        		+ "    </div>	");  
        try 
        {  
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", "");  
            Statement stmt = con.createStatement();  
            String sql="select * from CONGTY";
            
            ResultSet rs = stmt.executeQuery(sql); 
            
            out.println("<table class=customers>");
            out.println("<tr><th>Mã Công Ty</th>"
            		+ "<th>Tên Công Ty</th>"
            		+ "<th>Địa Chỉ</th>"
            		+ "<th>Số Lượng Nhân Viên</th>"
            		+ "<th>Số Lượng Chứng Khoán</th>"
            		+ "<th>Ngày Niêm Yết</th><th><a href=\"SearchCT.html\">Tìm Kiếm</a> | <a href='createCT.html'>Thêm Mới</a></th> </tr>");
            while (rs.next()) 
            {  
            	int MACONGTY= rs.getInt("MACONGTY");
            	String TENCONGTY = rs.getString("TENCONGTY");
            	String DIACHI = rs.getString("DIACHI");
            	int SOLUONGNHANVIEN= rs.getInt("SOLUONGNHANVIEN");
            	int SOLUONGCHUNGKHOAN= rs.getInt("SOLUONGCHUNGKHOAN");
            	Date NGAYNIEMYET= rs.getDate("NGAYNIEMYET");
            	
            	
            	out.println("<tr><td>" + MACONGTY + "</td>"
            			+ "<td>" + TENCONGTY + " </td>"
            					+ " <td>" + DIACHI + " </td>"
            							+ " <td>" +SOLUONGNHANVIEN + " </td>"
            									+ " <td>" + SOLUONGCHUNGKHOAN+ " </td>"
            											+ "<td>"+NGAYNIEMYET+"</td><td>"  + ""
            													+ "<a href='editCT1.jsp?MACONGTY="+MACONGTY+""
            															+ "&TENCONGTY="+TENCONGTY+""
            																	+ "&DIACHI="+DIACHI+""
            																			+ "&SOLUONGNHANVIEN="+SOLUONGNHANVIEN+""
            																					+ "&SOLUONGCHUNGKHOAN="+SOLUONGCHUNGKHOAN+""
            																							+ "&NGAYNIEMYET="+NGAYNIEMYET+"'>Sửa</a> | "+""
            															+ "<a href='deleteCT.html'>Xóa</a> "+"</td></tr>");
            }  
            out.println("</table>");
            out.println("</html></body>");  
            con.close();  
         }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
    }  
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		
	}

}
