import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditCT
 */
@WebServlet("/EditCT")
public class EditCT extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditCT() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html; charset=UTF-8"); 
		req.setCharacterEncoding("UTF-8"); 
		 PrintWriter out = res.getWriter();  
	    out.println("<html><meta charset='UTF-8'><body>");  
		
		
		// TODO Auto-generated method stub
	    int MACONGTY = Integer.parseInt(req.getParameter("MACONGTY"));
        String TENCONGTY = req.getParameter("TENCONGTY");
        String DIACHI = req.getParameter("DIACHI");
        int SOLUONGNHANVIEN = Integer.parseInt(req.getParameter("SOLUONGNHANVIEN"));
        int SOLUONGCHUNGKHOAN = Integer.parseInt(req.getParameter("SOLUONGCHUNGKHOAN"));
        Date NGAYNIEMYET = Date.valueOf(req.getParameter("NGAYNIEMYET"));
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", ""); 
            Statement stmt = con.createStatement();
            String sql = "UPDATE CONGTY SET TENCONGTY = ?, DIACHI = ?, SOLUONGNHANVIEN = ?, SOLUONGCHUNGKHOAN = ?, NGAYNIEMYET = ? WHERE MACONGTY = ?";
            System.out.println(sql);
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, TENCONGTY);
            statement.setString(2, DIACHI);
            statement.setInt(3, SOLUONGNHANVIEN);
            statement.setInt(4,SOLUONGCHUNGKHOAN);
            statement.setDate(5,NGAYNIEMYET);
            statement.setInt(6,MACONGTY);
            statement.executeUpdate();
            res.sendRedirect("DSCT");
            stmt.close();
            statement.close();
            con.close();
             
        } catch (Exception e) {
          System.out.println("Error");
        }
	}

}
