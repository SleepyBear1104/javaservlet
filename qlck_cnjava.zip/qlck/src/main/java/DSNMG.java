

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DSNMG
 */
@WebServlet("/DSNMG")
public class DSNMG extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DSNMG() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setCharacterEncoding("UTF-8");
        PrintWriter out = res.getWriter();  
        res.setContentType("text/html");  
        out.println("<html> <head> <link rel=\"stylesheet\" href=\"form.css\" /><link rel=\"stylesheet\" href=\"tables.css\" /> </head> <body>");
        out.println("<div class=\"header\">\r\n"
        		+ "        <div class=\"bar\">\r\n"
        		+ "            <div class=\"menu\">\r\n"
        		+ "                <ul>\r\n"
        		+ "                    <li></li>\r\n"
        		+ "                    <li><a href=\"home.html\">Trang Chủ</a></li>\r\n"
        		+ "                    <li><a href=\"DSNMG\">Nhà Môi Giới</a></li>\r\n"
        		+ "                    <li><a href=\"DSKH\">Khách Hàng</a></li>\r\n"
        		+ "                    <li><a href=\"DSCT\">Công Ty</a></li>\r\n"
        		+ "                    <li><a href=\"DSGD\">Giao Dịch</a></li>\r\n"
        		+ "                    <li><a href=\"DSDBG\">Diễn Biến Giá</a></li>\r\n"
        		+ "                </ul>\r\n"
        		+ "            </div>\r\n"
        		+ "        </div>\r\n"
        		+ "    </div>	");
     
        try 
        {  
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", "");  
            Statement stmt = con.createStatement();  
            String sql="select * from NHAMOIGIOI";
            System.out.println(sql);
            
            ResultSet rs = stmt.executeQuery(sql);
          
            out.println("<table class=customers");
            out.println("<tr><th>Mã nhà môi giới</th>"
            		+ "<th>Tên nhà môi giới</th>"
            		+ "<th>Địa chỉ</th>"
            		+ "<th>Số điện thoại</th>"
            		+ "<th><a href=\"sNMG.html\">Tìm Kiếm</a> | <a href=\"createNMG.html\">Thêm Mới</a></th>"+ " </tr>");
            while (rs.next()) 
            {  
            	int MANHAMOIGIOI = rs.getInt("MANHAMOIGIOI");
            	String TENNHAMOIGIOI = rs.getString("TENNHAMOIGIOI");
            	String DIACHI = rs.getString("DIACHI");
            	String SDT= rs.getString("SDT");
            	
          
            	out.println("<tr><td>" + MANHAMOIGIOI + ""
            			+ "</td><td>" + TENNHAMOIGIOI + ""
            					+ "</td> <td>" + DIACHI + ""
            							+ "</td> <td>" + SDT + ""
            									+ "</td><td>" + 
            							"<a href='editNMG1.jsp?MANHAMOIGIOI="+MANHAMOIGIOI+"&TENNHAMOIGIOI="+TENNHAMOIGIOI+"&DIACHI="+DIACHI+"&SDT="+SDT+"'>Sửa</a> | "+ "<a href='deleteNMG.html'>Xóa</a>" +"</td></tr>");
            }  
            out.println("</table>");
            out.println("</html></body>");  
            con.close();  
         }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
    }  
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		
	}

}
