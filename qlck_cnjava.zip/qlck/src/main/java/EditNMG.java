import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class EditNMG
 */
@WebServlet("/EditNMG")
public class EditNMG extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditNMG() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8"); 
		req.setCharacterEncoding("UTF-8"); 
		 PrintWriter out = res.getWriter();  
	    out.println("<html><meta charset='UTF-8'><body>");  
		
		
		// TODO Auto-generated method stub
	    
	    
	    
	    int MANHAMOIGIOI = Integer.parseInt(req.getParameter("MANHAMOIGIOI"));
        String TENNHAMOIGIOI = req.getParameter("TENNHAMOIGIOI");
        String DIACHI = req.getParameter("DIACHI");
        String SDT = req.getParameter("SDT");
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", ""); 
            Statement stmt = con.createStatement();
            String sql = "UPDATE NHAMOIGIOI SET TENNHAMOIGIOI = ?, DIACHI = ?, SDT = ? WHERE MANHAMOIGIOI = ?";
            System.out.println(sql);
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, TENNHAMOIGIOI);
            statement.setString(2, DIACHI);
            statement.setString(3, SDT);
            statement.setInt(4,MANHAMOIGIOI);
            statement.executeUpdate();
            res.sendRedirect("DSNMG");
            stmt.close();
            statement.close();
            con.close();
             
        } catch (Exception e) {
          System.out.println("Error");
        }
        }
        
	}
