
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditKH
 */
@WebServlet("/EditKH")
public class EditKH extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditKH() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8"); 
		req.setCharacterEncoding("UTF-8"); 
		 PrintWriter out = res.getWriter();  
	    out.println("<html><meta charset='UTF-8'><body>");  
		
		
		// TODO Auto-generated method stub
	    
	    
	    
	    int MAKHACHHANG = Integer.parseInt(req.getParameter("MAKHACHHANG"));
        String TENKHACHHANG = req.getParameter("TENKHACHHANG");
        String DIACHI = req.getParameter("DIACHI");
        String SDT = req.getParameter("SDT");
        int TONGTHUNHAP = Integer.parseInt(req.getParameter("TONGTHUNHAP"));
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", ""); 
            Statement stmt = con.createStatement();
            String sql = "UPDATE KHACHHANG SET TENKHACHHANG = ?, DIACHI = ?, SDT = ?, TONGTHUNHAP = ? WHERE MAKHACHHANG = ?";
            System.out.println(sql);
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, TENKHACHHANG);
            statement.setString(2, DIACHI);
            statement.setString(3, SDT);
            statement.setInt(4,TONGTHUNHAP);
            statement.setInt(5,MAKHACHHANG);
            statement.executeUpdate();
            res.sendRedirect("DSKH");
            stmt.close();
            statement.close();
            con.close();
             
        } catch (Exception e) {
          System.out.println("Error");
        }
        }
}
