

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditGD1
 */
@WebServlet("/EditGD1")
public class EditGD1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditGD1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8"); 
		req.setCharacterEncoding("UTF-8"); 
		 PrintWriter out = res.getWriter();  
	    out.println("<html><meta charset='UTF-8'><body>");  
		
		
		// TODO Auto-generated method stub
	    
	    
	    
	    int MAGIAODICH = Integer.parseInt(req.getParameter("MAGIAODICH"));
	    Date NGAYGIAODICH = Date.valueOf(req.getParameter("NGAYGIAODICH"));
	    int MAKHMUA = Integer.parseInt(req.getParameter("MAKHMUA"));
	    int MAKHBAN = Integer.parseInt(req.getParameter("MAKHBAN"));
	    int SOLUONG = Integer.parseInt(req.getParameter("SOLUONG"));
	    int MANHAMOIGIOI = Integer.parseInt(req.getParameter("MANHAMOIGIOI"));
	    int MACONGTY = Integer.parseInt(req.getParameter("MACONGTY"));
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", ""); 
            Statement stmt = con.createStatement();
            String sql = "UPDATE GIAODICH SET NGAYGIAODICH = ?, MAKHMUA = ?, MAKHBAN = ?, SOLUONG=?, MANHAMOIGIOI=?, MACONGTY=? WHERE MAGIAODICH = ?";
            System.out.println(sql);
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setDate(1, NGAYGIAODICH);
            statement.setInt(2,MAKHMUA);
            statement.setInt(3,MAKHBAN);
            statement.setInt(4,SOLUONG);
            statement.setInt(5,MANHAMOIGIOI);
            statement.setInt(6,MACONGTY);
            statement.setInt(7,MAGIAODICH);
            statement.executeUpdate();
            res.sendRedirect("DSGD");
            stmt.close();
            statement.close();
            con.close();
             
        } catch (Exception e) {
          System.out.println("Error");
        }
        }

}
