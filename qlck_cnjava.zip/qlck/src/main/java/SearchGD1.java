

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchGD1
 */
@WebServlet("/SearchGD1")
public class SearchGD1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchGD1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html> <head> <link rel=\"stylesheet\" href=\"FormSearch.css\" /><link rel=\"stylesheet\" href=\"tables.css\" /> </head> <body>");
        out.println("<div class=\"header\">\r\n"
        		+ "        <div class=\"bar\">\r\n"
        		+ "            <div class=\"menu\">\r\n"
        		+ "                <ul>\r\n"
        		+ "                    <li></li>\r\n"
        		+ "                    <li><a href=\"home.html\">Trang Chủ</a></li>\r\n"
        		+ "                    <li><a href=\"DSNMG\">Nhà Môi Giới</a></li>\r\n"
        		+ "                    <li><a href=\"DSKH\">Khách Hàng</a></li>\r\n"
        		+ "                    <li><a href=\"DSCT\">Công Ty</a></li>\r\n"
        		+ "                    <li><a href=\"DSGD\">Giao Dịch</a></li>\r\n"
        		+ "                    <li><a href=\"DSDBG\">Diễn Biến Giá</a></li>\r\n"
        		+ "                </ul>\r\n"
        		+ "            </div>\r\n"
        		+ "        </div>\r\n"
        		+ "    </div>	");

        int MAGIAODICH = Integer.parseInt(request.getParameter("MAGIAODICH"));

        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", "");
            stmt = con.createStatement();

            String sql = "SELECT * FROM GIAODICH WHERE MAGIAODICH = " + MAGIAODICH;
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int foundMAGIAODICH = rs.getInt("MAGIAODICH");
                Date NGAYGIAODICH = rs.getDate("NGAYGIAODICH");
                int MAKHMUA = rs.getInt("MAKHMUA");
                int MAKHBAN = rs.getInt("MAKHBAN");
                int SOLUONG= rs.getInt("SOLUONG");
                int MANHAMOIGIOI= rs.getInt("MANHAMOIGIOI");
                int MACONGTY= rs.getInt("MACONGTY");
                out.println("<div class=\"container\">\r\n"
                		+ "      <div class=\"form-wrapper\">\r\n"
                		+ "        <h3 class=\"heading\" align=\"center\">THÔNG TIN GIAO DỊCH</h3>    \r\n"
                		+ "        <form class=\"form\" >\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Mã Giao Dịch: " + foundMAGIAODICH + "<br></span>"
                		
                		+ "          </div>\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Ngày Giao Dịch: " + NGAYGIAODICH + "<br></span>"
                		
                		+ "          </div>\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Mã Khách Hàng Mua: " + MAKHMUA  + "<br></span>"
                		
                		+ "          </div>\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Mã Khách Hàng Bán: " + MAKHBAN + "<br></span>"
                		+ "          </div>\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Số Lượng: " + SOLUONG + "<br></span>"
                		+ "          </div>\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Mã Nhà Môi Giới: " + MANHAMOIGIOI + "<br></span>"
                		+ "          </div>\r\n"
                		+ "          <div class=\"input-field\">\r\n"
                		+ "            <span>Mã Công Ty: " + MACONGTY + "<br></span>"
                		+ "          </div>\r\n"
                		+ "          <br>\r\n"
                		+ "          <div align=\"center\" class=\"BT\">\r\n"
                		+ "            <input type=\"button\" value=\"Trở Về\"  class=\"button1\" onclick=\"window.location.href='DSGD';\"/>\r\n"
                		+ "        </div>\r\n"
                		+ "        </form>\r\n"
                		+ "      </div>\r\n"
                		+ "    </div>");
               
            } else {
                out.println("<div class=\"container\">\r\n"
                		+ "      <div class=\"form-wrapper\">\r\n"
                		+ "        <h3 class=\"heading\" align=\"center\">KHÔNG TÌM THẤY GIAO DỊCH</h3>    \r\n"
                		+ "        <form class=\"form\">\r\n"
                		+ "          <br>\r\n"
                		+ "          <div align=\"center\" class=\"BT\">\r\n"
                		+ "           <input type=\"button\" value=\"Trở Về\"  class=\"button1\" onclick=\"window.location.href='DSGD';\"/>&emsp;\r\n"
                		+ "        </div>\r\n"
                		+ "        </form>\r\n"
                		+ "      </div>\r\n"
                		+ "    </div>");
            }
            
            out.println("</html></body>");  
        } catch (Exception e) {
            out.println("Lỗi: " + e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
