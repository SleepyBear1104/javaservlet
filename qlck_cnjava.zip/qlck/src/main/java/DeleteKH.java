import java.sql.*;
import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteKH
 */
@WebServlet("/DeleteKH")
public class DeleteKH extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteKH() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html> <head> <link rel=\"stylesheet\" href=\"FormSearch.css\" /><link rel=\"stylesheet\" href=\"tables.css\" /> </head> <body>");
        out.println("<div class=\"header\">\r\n"
        		+ "        <div class=\"bar\">\r\n"
        		+ "            <div class=\"menu\">\r\n"
        		+ "                <ul>\r\n"
        		+ "                    <li></li>\r\n"
        		+ "                    <li><a href=\"home.html\">Trang Chủ</a></li>\r\n"
        		+ "                    <li><a href=\"DSNMG\">Nhà Môi Giới</a></li>\r\n"
        		+ "                    <li><a href=\"DSKH\">Khách Hàng</a></li>\r\n"
        		+ "                    <li><a href=\"DSCT\">Công Ty</a></li>\r\n"
        		+ "                    <li><a href=\"DSGD\">Giao Dịch</a></li>\r\n"
        		+ "                    <li><a href=\"DSDBG\">Diễn Biến Giá</a></li>\r\n"
        		+ "                </ul>\r\n"
        		+ "            </div>\r\n"
        		+ "        </div>\r\n"
        		+ "    </div>	");	

        int MAKHACHHANG = Integer.parseInt(request.getParameter("MAKHACHHANG"));

        Connection con = null;
        Statement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlck", "root", "");
            stmt = con.createStatement();

            String sql = "DELETE FROM KHACHHANG WHERE MAKHACHHANG = " + MAKHACHHANG;
            int rowsDeleted = stmt.executeUpdate(sql);

            if (rowsDeleted > 0) {
            	out.println("<div class=\"container\">\r\n"
            			+ "      <div class=\"form-wrapper\">\r\n"
            			+ "        <h3 class=\"heading\" align=\"center\">XÓA THÀNH CÔNG</h3>    \r\n"
            			+ "        <form class=\"form\" method=\"post\" action=\"SearchNMG1\" >\r\n"
            			+ "          <br>\r\n"
            			+ "          <div align=\"center\" class=\"BT\">\r\n"
            			+ "           <input type=\"button\" value=\"Trở Về\"  class=\"button1\" onclick=\"window.location.href='DSKH';\"/>&emsp;\r\n"
            			+ "        </div>\r\n"
            			+ "        </form>\r\n"
            			+ "      </div>\r\n"
            			+ "    </div>");
                
            } else {
                out.println("<div class=\"container\">\r\n"
                		+ "      <div class=\"form-wrapper\">\r\n"
                		+ "        <h3 class=\"heading\" align=\"center\">XÓA THẤT BẠI </h3>    \r\n"
                		+ "        <form class=\"form\" >\r\n"
                		+ "          <br>\r\n"
                		+ "          <div align=\"center\" class=\"BT\">\r\n"
                		+ "           <input type=\"button\" value=\"Trở Về\"  class=\"button1\" onclick=\"window.location.href='DSKH';\"/>&emsp;\r\n"
                		+ "        </div>\r\n"
                		+ "        </form>\r\n"
                		+ "      </div>\r\n"
                		+ "    </div>");
            }
            out.println("</html></body>");  
        } catch (Exception e) {
            out.println("Lỗi: " + e.getMessage());
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
