-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2023 at 10:37 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlck`
--

-- --------------------------------------------------------

--
-- Table structure for table `congty`
--

CREATE TABLE `congty` (
  `MACONGTY` int(11) NOT NULL,
  `TENCONGTY` varchar(50) NOT NULL,
  `DIACHI` varchar(50) NOT NULL,
  `SOLUONGNHANVIEN` int(11) NOT NULL,
  `SOLUONGCHUNGKHOAN` int(11) NOT NULL,
  `NGAYNIEMYET` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `congty`
--

INSERT INTO `congty` (`MACONGTY`, `TENCONGTY`, `DIACHI`, `SOLUONGNHANVIEN`, `SOLUONGCHUNGKHOAN`, `NGAYNIEMYET`) VALUES
(2001, 'abc', 'XYZ', 123, 321, '2000-02-10'),
(2002, 'Công ty chứng khoán SSI', '50 Hoàng Văn Thụ TP HCM', 1592, 1590, '2006-12-15'),
(2003, 'Công ty chứng khoán VNDirect', '72 Điện Biên Phủ Hà Nội', 1535, 603, '2010-03-30'),
(2004, 'Công ty chứng khoán TP HCM', '95 Nguyễn Thái Học TP HCM', 658, 5063, '2009-05-19'),
(2005, 'Công ty chứng khoán Kỹ Thương', '98 Trần Duy Hưng Hà Nội', 11742, 2067, '2018-06-04'),
(2006, 'Công ty chứng khoán MB', '192 Cộng Hòa TP HCM', 16085, 6237, '2011-11-01'),
(2007, 'Công ty chứng khoán FPT', '30 Hai Bà Trưng Hà Nội', 45903, 9306, '2006-12-13'),
(2008, 'Công ty chứng khoán ACB', '30 Hai Bà Trưng Hà Nội', 45903, 9306, '2006-12-13'),
(2009, 'Công ty chứng khoán Bảo Việt', '30 Võ Chí Công Đà Nẵng', 673, 3567, '2006-12-18'),
(2010, 'Công ty chứng khoán BIDV', '85 Cách Mạng Tháng Tám TP HCM', 28195, 9527, '2014-10-30'),
(2011, 'Công ty chứng khoán Thiên Việt', '90 Lý Thái Tổ TP HCM', 98, 1324, '2006-12-25'),
(2012, 'Công Ty chứng khoán Quốc Gia', '263 Võ Thị Sáu TP HCM', 300, 3972, '2006-06-25'),
(2013, 'Công ty chứng khoán Dầu khí', '399 Trần Hưng Đạo Hà Nội', 160, 2353, '2010-07-21'),
(2014, 'Công ty chứng khoán Vina', '222 Hàm Long Hà Nội', 100, 1230, '2006-12-26'),
(2015, 'Công ty chứng khoán Việt Tín', '3 Lê Văn Hưu Hà Nội', 95, 1730, '2014-10-30');

-- --------------------------------------------------------

--
-- Table structure for table `dienbiengia`
--

CREATE TABLE `dienbiengia` (
  `MACONGTY` int(11) NOT NULL,
  `NGAYDIENBIEN` date NOT NULL,
  `GIA1CHUNGKHOAN` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `dienbiengia`
--

INSERT INTO `dienbiengia` (`MACONGTY`, `NGAYDIENBIEN`, `GIA1CHUNGKHOAN`) VALUES
(2001, '2021-02-12', 200000),
(2002, '2021-02-19', 200000),
(2002, '2021-03-31', 500000),
(2003, '2022-08-23', 450000),
(2004, '2022-07-19', 350000),
(2005, '2023-02-21', 350000),
(2006, '2023-05-26', 357000),
(2007, '2022-02-15', 500000),
(2008, '2023-04-16', 475000),
(2009, '2022-12-13', 300000),
(2010, '2022-07-01', 500000),
(2011, '2023-02-15', 300000),
(2012, '2023-07-26', 267000),
(2013, '2023-07-13', 150000),
(2014, '2023-03-12', 100000),
(2015, '2022-08-23', 60000);

-- --------------------------------------------------------

--
-- Table structure for table `giaodich`
--

CREATE TABLE `giaodich` (
  `MAGIAODICH` int(11) NOT NULL,
  `NGAYGIAODICH` date NOT NULL,
  `MAKHMUA` int(11) NOT NULL,
  `MAKHBAN` int(11) NOT NULL,
  `SOLUONG` int(11) NOT NULL,
  `MANHAMOIGIOI` int(11) NOT NULL,
  `MACONGTY` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `giaodich`
--

INSERT INTO `giaodich` (`MAGIAODICH`, `NGAYGIAODICH`, `MAKHMUA`, `MAKHBAN`, `SOLUONG`, `MANHAMOIGIOI`, `MACONGTY`) VALUES
(4001, '2022-02-10', 3003, 3006, 32, 1006, 2005),
(4002, '2022-02-02', 3003, 3005, 253, 1006, 2002),
(4003, '2022-08-29', 3003, 3004, 100, 1003, 2003),
(4004, '2022-07-26', 3004, 3005, 54, 1004, 2004),
(4005, '2023-02-25', 3005, 3006, 60, 1006, 2006),
(4006, '2023-06-02', 3006, 3007, 53, 1006, 2006),
(4007, '2022-02-21', 3007, 3008, 36, 1007, 2007),
(4008, '2023-04-25', 3008, 3001, 73, 1008, 2008),
(4009, '2022-12-29', 3001, 3003, 500, 1009, 2009),
(4010, '2022-07-15', 3005, 3007, 799, 1010, 2010),
(4011, '2023-07-25', 3004, 3006, 600, 1011, 2011),
(4012, '2023-02-21', 3001, 3005, 299, 1012, 2012),
(4013, '2023-07-26', 3003, 3007, 50, 1013, 2013),
(4014, '2023-05-02', 3006, 3004, 51, 1015, 2014),
(4015, '2019-03-25', 3003, 3004, 32, 1004, 2006);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `MAKHACHHANG` int(11) NOT NULL,
  `TENKHACHHANG` varchar(30) NOT NULL,
  `DIACHI` varchar(50) NOT NULL,
  `SDT` varchar(11) NOT NULL,
  `TONGTHUNHAP` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`MAKHACHHANG`, `TENKHACHHANG`, `DIACHI`, `SDT`, `TONGTHUNHAP`) VALUES
(3001, 'Hoàng Hải Đăng', 'Hà Nội', '02873007777', 50000000),
(3002, 'Vũ Quốc Tùng', 'Hồ Chí Minh', '02873007777', 50000000),
(3003, 'Nguyễn Tấn Đạt', '33 Lê Duẩn Long An', '0363935141', 45000000),
(3004, 'Nguyễn Bá Hùng', '30 N8 Bình Dương', '0389693375', 45000000),
(3005, 'Huỳnh Anh Khoa', '35 Lê Duẩn Long An', '0876541232', 60000000),
(3006, 'Nguyễn Thị Mỹ Lệ', '30 Nguyễn Thiếp Bình Định', '0795534869', 40000000),
(3007, 'Trần Thiên Nam', '210 Nguyễn Văn Linh TP HCM', '0987654321', 40000000),
(3008, 'Nguyễn Khánh Linh', '7 Trần Phú Hà Nội', '0654228198', 50000000);

-- --------------------------------------------------------

--
-- Table structure for table `nhamoigioi`
--

CREATE TABLE `nhamoigioi` (
  `MANHAMOIGIOI` int(11) NOT NULL,
  `TENNHAMOIGIOI` varchar(50) NOT NULL,
  `DIACHI` varchar(50) NOT NULL,
  `SDT` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `nhamoigioi`
--

INSERT INTO `nhamoigioi` (`MANHAMOIGIOI`, `TENNHAMOIGIOI`, `DIACHI`, `SDT`) VALUES
(1001, 'Mirae Asset', 'Hà Nội', '02873007777'),
(1002, 's', 'avb', '123'),
(1003, 'Ngân hàng công thương', '30 Âu cơ TPHCM', '02439418868'),
(1004, 'Apec', '29 Lạc Long Quân TPHCM', '02343882882'),
(1005, 'Rồng Việt', '60 Cống Quỳnh TPHCM', '02862992006'),
(1006, 'An Bình', '55 Phạm Thế Hiển TPHCM', '0345672001'),
(1007, 'Asean', '201 Trương Định TPHCM', '0286654514'),
(1008, 'Etoro', '20 Cầu Giấy Hà Nội', '0812345678'),
(1009, 'Nhất Việt', '67 Phạm Văn Chí TPHCM', '0878945663'),
(1010, 'DNSE', '56 Bình Phú TPHCM', '02871059988'),
(1011, 'Trí Việt', '62 Kinh Dương Vương TPHCM', '02462732059'),
(1012, 'KIS Việt Nam', '39 Thái Hà Hà Nội', '02839148585'),
(1013, 'Liên Việt', '58 Trường Trinh TPHCM', '02462668668'),
(1014, 'JB Việt Nam', '150 Phạm Văn Đồng TPHCM', '0938707972'),
(1015, 'Tiên Phong', '6 Quang Trung Hà Nội', '02473073683');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` int(11) NOT NULL,
  `isvalid` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `congty`
--
ALTER TABLE `congty`
  ADD PRIMARY KEY (`MACONGTY`);

--
-- Indexes for table `dienbiengia`
--
ALTER TABLE `dienbiengia`
  ADD PRIMARY KEY (`MACONGTY`,`NGAYDIENBIEN`);

--
-- Indexes for table `giaodich`
--
ALTER TABLE `giaodich`
  ADD PRIMARY KEY (`MAGIAODICH`),
  ADD KEY `MAKHMUA` (`MAKHMUA`,`MAKHBAN`,`MANHAMOIGIOI`,`MACONGTY`),
  ADD KEY `MANHAMOIGIOI` (`MANHAMOIGIOI`),
  ADD KEY `MACONGTY` (`MACONGTY`),
  ADD KEY `MAKHBAN` (`MAKHBAN`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`MAKHACHHANG`);

--
-- Indexes for table `nhamoigioi`
--
ALTER TABLE `nhamoigioi`
  ADD PRIMARY KEY (`MANHAMOIGIOI`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dienbiengia`
--
ALTER TABLE `dienbiengia`
  ADD CONSTRAINT `dienbiengia_ibfk_1` FOREIGN KEY (`MACONGTY`) REFERENCES `congty` (`MACONGTY`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaodich`
--
ALTER TABLE `giaodich`
  ADD CONSTRAINT `giaodich_ibfk_1` FOREIGN KEY (`MANHAMOIGIOI`) REFERENCES `nhamoigioi` (`MANHAMOIGIOI`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaodich_ibfk_2` FOREIGN KEY (`MACONGTY`) REFERENCES `congty` (`MACONGTY`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaodich_ibfk_3` FOREIGN KEY (`MAKHMUA`) REFERENCES `khachhang` (`MAKHACHHANG`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaodich_ibfk_4` FOREIGN KEY (`MAKHBAN`) REFERENCES `khachhang` (`MAKHACHHANG`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
